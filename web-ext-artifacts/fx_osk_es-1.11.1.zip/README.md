# Firefox On Screen Keyboard (FX-OSK)
An on screen keyboard for Firefox for those in a kiosk environment.

You can find the add-on at https://addons.mozilla.org/en-US/firefox/addon/fx-osk/ if you wish to download to your Firefox for testing purposes or if you wish to use it, any suggestions for upgrades will be accepted gratefully, I can incorporate and update to Firefox.
